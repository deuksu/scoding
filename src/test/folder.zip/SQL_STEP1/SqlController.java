package com.security;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SqlController {

    private static final Logger log = LoggerFactory.getLogger(SqlController.class);

	
	@RequestMapping("/sql")
	public List<String> test(@RequestParam(value="name") String name) {
	     
		log.info("Start sql statement");
		List<String> rtn = new ArrayList<String>();
//		 SqlRowSet rs = jdbcTemplate.queryForRowSet("SELECT * FROM CUSTOMERS where FIRST_NAME ='" + name+"'");
//		 while (rs.next()) {
//             rtn.add(rs.getString("FIRST_NAME"));
//         }
		 
		 try (Connection conn = DriverManager.getConnection("jdbc:h2:mem:testdb", "sa", "");
		     Statement stat = conn.createStatement()) {
		     try (ResultSet rs = stat.executeQuery("SELECT * FROM CUSTOMERS where FIRST_NAME ='" + name+"'")) {
		         while (rs.next()) {
		             rtn.add(rs.getString("FIRST_NAME"));
		         }
		     }
		 } catch (Exception e) {
		     e.printStackTrace();
		 }
		 
		 log.info("END sql statement");
		 return rtn;
	}
}
